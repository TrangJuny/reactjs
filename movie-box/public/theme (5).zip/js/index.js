$('.menu-icon').click(()=>{
  $('.menu-icon+div').toggleClass('d-block');
})